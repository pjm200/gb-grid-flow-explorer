"""Loads the processed data the model and API need (cached)."""
from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache

import pandas as pd

from . import PROCESSED, load_yaml


@dataclass(frozen=True)
class ModelData:
    assets: pd.DataFrame        # id, name, tech, capacity_mw, energy_mwh, display/conn coords, country + one bool column per boundary
    ics: pd.DataFrame           # id, name, far_country, capacity_mw, gb_lat/lon, status + bool columns
    regions: pd.DataFrame       # id, name, lat, lon, shares, country + bool columns
    boundaries: list[str]       # usable boundary names, config order
    boundary_cfg: dict          # name -> config entry
    defaults: dict
    health: dict


def _props(name: str) -> pd.DataFrame:
    fc = json.loads((PROCESSED / name).read_text(encoding="utf-8"))
    return pd.DataFrame([f["properties"] for f in fc["features"]])


DATA_VERSION = "4"     # bump when prepare_data's output format changes; the server then re-prepares


def is_prepared() -> bool:
    marker = PROCESSED / "VERSION"
    return (PROCESSED / "assets.geojson").exists() and (PROCESSED / "inside_matrix.parquet").exists() \
        and marker.exists() and marker.read_text(encoding="utf-8").strip() == DATA_VERSION


@lru_cache(maxsize=1)
def load() -> ModelData:
    cfg = load_yaml("boundaries.yaml")
    js = PROCESSED / "inside_matrix.json"
    matrix = pd.read_json(js, orient="records") if js.exists() else pd.read_parquet(PROCESSED / "inside_matrix.parquet")
    names = [b for b in cfg["boundaries"] if b in matrix.columns]

    def join(df: pd.DataFrame, kind: str) -> pd.DataFrame:
        m = matrix[matrix["kind"] == kind].drop(columns="kind")
        return df.drop(columns=["inside"], errors="ignore").merge(m, on="id", how="left", validate="1:1")

    return ModelData(
        assets=join(_props("assets.geojson"), "asset"),
        ics=join(_props("interconnectors.geojson"), "interconnector"),
        regions=join(_props("demand_regions.geojson"), "region"),
        boundaries=names,
        boundary_cfg={b: cfg["boundaries"][b] for b in names},
        defaults=cfg["defaults"],
        health=json.loads((PROCESSED / "health.json").read_text(encoding="utf-8")),
    )


def static_payload() -> dict:
    """Everything the map needs that does not change between simulations."""
    out = {}
    for key, fname in [("land", "land.geojson"), ("neighbours", "neighbours.geojson"),
                       ("boundaries", "boundaries.geojson"), ("boundary_sides", "boundary_sides.geojson"),
                       ("assets", "assets.geojson"), ("interconnectors", "interconnectors.geojson"),
                       ("hvdc_internal", "hvdc_internal.geojson"), ("regions", "demand_regions.geojson"),
                       ("embedded_sites", "embedded_sites.geojson")]:
        path = PROCESSED / fname
        out[key] = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"type": "FeatureCollection", "features": []}
    d = load()
    from . import demand as dem

    emb = dem.embedded_capacity()
    costs = load_yaml("costs.yaml")
    out["meta"] = {
        "boundary_order": d.boundaries,
        "summer_derate": d.defaults["summer_derate"],
        "emb_solar_capacity_mw": emb["solar_capacity_mw"],
        "emb_wind_capacity_mw": emb["wind_capacity_mw"],
        "homes_kwh_per_day": costs["homes_kwh_per_day"],
        "start_soc": costs["storage"]["start_soc"],
        "battery_default_duration_h": costs["storage"]["battery"]["default_duration_h"],
        "demand_source": dem.source(),
        "embedded_min_mw": load_yaml("ingest.yaml")["repd"]["show_embedded_min_mw"],
        "datasets": {k: v.get("status") for k, v in d.health.get("datasets", {}).items()},
    }
    return out
