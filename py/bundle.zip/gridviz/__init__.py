"""GB Grid Flow Explorer - data, geometry and dispatch model."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "config"
RAW = ROOT / "data" / "raw"
SEED = ROOT / "data" / "seed"
PROCESSED = ROOT / "data" / "processed"
STATIC = ROOT / "static"

N_PERIODS = 48
DT_H = 0.5


def load_yaml(name: str) -> dict:
    import yaml

    with open(CONFIG / name, encoding="utf-8") as f:
        return yaml.safe_load(f)
