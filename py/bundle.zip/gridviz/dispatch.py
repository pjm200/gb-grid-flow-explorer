"""Two-pass whole-day linear-programme dispatch (spec sections 6.1, 6.5 - 6.7).

Pass 1 ("market")      : cheapest way to meet demand with no boundary limits (copper plate).
Pass 2 ("constrained") : the same problem plus the boundary-cut limits.
Constraint actions     = pass 2 minus pass 1.

Transport model: the flow across a boundary is the net injection on its inside side,

    F[b,t] = sum over everything inside b of (generation + discharge - charge + import - demand)

so the model only needs to know which side of each boundary every asset sits on.

Assets with the same technology on the same side of every boundary are interchangeable
to the LP, so they are solved as one "group" and shared out pro rata for display.
"""
from __future__ import annotations

import time
import zlib
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.optimize import linprog

from . import DT_H, N_PERIODS, load_yaml
from . import data as store
from . import demand as dem
from . import weather as wx
from .models import SimRequest

T = N_PERIODS
THERMAL = ["nuclear", "biomass", "ccgt", "ocgt"]
RENEWABLE = ["wind_offshore", "wind_onshore", "solar"]
STORAGE = ["pumped_storage", "battery"]
BLOCKS = ["G", "R", "CH", "DIS", "SOC", "IC", "U", "SP"]
DEV_BLOCKS = ["G", "R", "CH", "DIS", "IC"]        # blocks that get a "stay near the market" tie-break
MAX_STORAGE_FIXES = 8


@dataclass
class Groups:
    """One LP unit per row. `members` maps back to rows of the asset / IC / region tables."""
    n: int = 0
    members: list = field(default_factory=list)       # list of index arrays
    weights: list = field(default_factory=list)       # pro-rata weights (n_members,) or (n_members, T)
    S: np.ndarray = None                              # (n_boundaries, n) 1.0 where the group is inside
    tech: list = field(default_factory=list)


def _sig_groups(df: pd.DataFrame, bnames: list[str], extra_keys: list[str]) -> list[tuple[tuple, np.ndarray]]:
    if df.empty:
        return []
    keys = extra_keys + bnames
    return [(k if isinstance(k, tuple) else (k,), np.asarray(idx))
            for k, idx in df.groupby(keys, sort=True).indices.items()]


def _S(df: pd.DataFrame, members: list, bnames: list[str]) -> np.ndarray:
    if not members:
        return np.zeros((len(bnames), 0))
    return np.array([[float(df[b].iloc[m[0]]) for m in members] for b in bnames])


def _kron(M: np.ndarray) -> sparse.csr_matrix:
    """Apply a (rows x units) matrix independently in each of the T periods."""
    if M.shape[1] == 0 or M.shape[0] == 0:
        return sparse.csr_matrix((M.shape[0] * T, M.shape[1] * T))
    return sparse.kron(sparse.csr_matrix(M), sparse.identity(T, format="csr"), format="csr")


class Problem:
    def __init__(self, req: SimRequest):
        self.req = req
        d = store.load()
        self.costs = c = load_yaml("costs.yaml")
        self.bnames = bn = d.boundaries
        self.bcfg = d.boundary_cfg
        nB = len(bn)

        # ---------------------------------------------------------- what is in the system
        ex_types, ex_ids = set(req.excluded_types), set(req.excluded_assets)
        a = d.assets[~d.assets["tech"].isin(ex_types) & ~d.assets["id"].isin(ex_ids)].reset_index(drop=True)
        ic = d.ics[d.ics["status"] == "operational"]
        if "interconnector" in ex_types:
            ic = ic.iloc[0:0]
        ic = ic[~ic["id"].isin(ex_ids)].reset_index(drop=True)
        self.assets, self.ics, self.regions = a, ic, d.regions.reset_index(drop=True)
        rg = self.regions

        # ------------------------------------------------------------------- weather
        def kinds(tech, country):
            return ["offshore" if t == "wind_offshore" else
                    ("scotland_onshore" if ctry == "Scotland" else "england_wales_onshore")
                    for t, ctry in zip(tech, country)]

        cap = a["capacity_mw"].to_numpy(float)
        self.avail = np.zeros((len(a), T))                        # MW the weather allows (renewables)
        is_wind = a["tech"].isin(["wind_offshore", "wind_onshore"]).to_numpy()
        is_solar = (a["tech"] == "solar").to_numpy()
        if is_wind.any():
            w = a[is_wind]
            self.avail[is_wind] = cap[is_wind, None] * wx.wind_cf(
                req.wind, w["display_lat"], w["display_lon"], kinds(w["tech"], w["country"]), req.seed, req.front)
        if is_solar.any():
            s = a[is_solar]
            self.avail[is_solar] = cap[is_solar, None] * wx.solar_cf(
                req.cloud, req.season, s["display_lat"], s["display_lon"], req.seed)

        emb = dem.embedded_capacity()
        self.emb_wind = (emb["wind_capacity_mw"] * rg["emb_wind_share"].to_numpy()[:, None] * wx.wind_cf(
            req.wind, rg["lat"], rg["lon"], kinds(["wind_onshore"] * len(rg), rg["country"]), req.seed, req.front))
        self.emb_solar = (emb["solar_capacity_mw"] * rg["emb_solar_share"].to_numpy()[:, None] * wx.solar_cf(
            req.cloud, req.season, rg["lat"], rg["lon"], req.seed))
        self.underlying = dem.regional_underlying_mw(req.season, rg["demand_share"].to_numpy())
        self.net_demand = self.underlying - self.emb_wind - self.emb_solar          # (regions, T)

        all_wind_cap = cap[is_wind].sum() + emb["wind_capacity_mw"]
        all_solar_cap = cap[is_solar].sum() + emb["solar_capacity_mw"]
        self.wind_lf = (self.avail[is_wind].sum(0) + self.emb_wind.sum(0)) / max(all_wind_cap, 1.0)
        self.solar_lf = (self.avail[is_solar].sum(0) + self.emb_solar.sum(0)) / max(all_solar_cap, 1.0)

        # -------------------------------------------------------------------- groups
        # thermal
        th = a[a["tech"].isin(THERMAL)]
        self.gG = g = Groups()
        g_cap, g_min, g_cost = [], [], []
        for key, pos in _sig_groups(th, bn, ["tech"]):
            idx = th.index.to_numpy()[pos]
            tech = key[0]
            ccap = cap[idx] * c["availability"].get(tech, 1.0)
            u = zlib.crc32(repr(key).encode()) / 2 ** 32
            g.members.append(idx); g.weights.append(ccap / ccap.sum()); g.tech.append(tech)
            g_cap.append(ccap.sum())
            g_min.append(c["must_run_fraction"].get(tech, 0.0) * ccap.sum())
            g_cost.append(u)                         # placeholder: merit-order position, costed below
        g.n = len(g.members); g.S = _S(a, g.members, bn)
        self.g_cap, self.g_min = np.array(g_cap), np.array(g_min)
        # Each technology gets a supply curve, not one price: plants differ in efficiency, so the
        # groups are lined up (in a fixed pseudo-random order) from base - spread to base + spread
        # by cumulative capacity. Without this every CCGT costs the same, the price is flat all
        # day, and storage has nothing to arbitrage.
        self.g_cost = np.zeros(g.n)
        for tech in set(g.tech):
            ks = sorted((k for k in range(g.n) if g.tech[k] == tech), key=lambda k: g_cost[k])
            caps = self.g_cap[ks]
            mid = (np.cumsum(caps) - caps / 2) / caps.sum()
            self.g_cost[ks] = c["marginal_cost"][tech] + (2 * mid - 1) * c["cost_spread"].get(tech, 0.0)

        # renewables
        rn = a[a["tech"].isin(RENEWABLE)]
        self.gR = r = Groups()
        r_av, r_cost = [], []
        for key, pos in _sig_groups(rn, bn, ["tech"]):
            idx = rn.index.to_numpy()[pos]
            av = self.avail[idx]
            tot = av.sum(0)
            r.members.append(idx); r.tech.append(key[0])
            r.weights.append(np.divide(av, tot, out=np.zeros_like(av), where=tot > 1e-9))
            r_av.append(tot)
            r_cost.append(-c["curtailment_cost"][key[0]])
        r.n = len(r.members); r.S = _S(a, r.members, bn)
        self.r_avail = np.array(r_av).reshape(r.n, T)
        self.r_cost = np.array(r_cost)

        # storage: pumped storage one by one, batteries grouped by duration so pro-rata is exact
        st = a[a["tech"].isin(STORAGE)].copy()
        default_h = c["storage"]["battery"]["default_duration_h"]
        st["energy_mwh"] = st["energy_mwh"].fillna(st["capacity_mw"] * default_h)
        st["_dur"] = (st["energy_mwh"] / st["capacity_mw"]).round(1)
        st["_key"] = np.where(st["tech"] == "pumped_storage", st["id"], "battery")
        self.energy = np.zeros(len(a)); self.energy[st.index] = st["energy_mwh"]
        self.gS = s = Groups()
        s_P, s_E, s_eta = [], [], []
        for key, pos in _sig_groups(st, bn, ["tech", "_key", "_dur"]):
            idx = st.index.to_numpy()[pos]
            tech = key[0]
            P = cap[idx] * c["availability"].get(tech, 1.0)
            s.members.append(idx); s.weights.append(P / P.sum()); s.tech.append(tech)
            s_P.append(P.sum()); s_E.append(self.energy[idx].sum())
            s_eta.append(np.sqrt(c["storage"][tech]["round_trip_efficiency"]))
        s.n = len(s.members); s.S = _S(a, s.members, bn)
        self.s_P, self.s_E, self.s_eta = map(np.array, (s_P, s_E, s_eta))
        self.soc0 = (req.start_soc if req.start_soc is not None else c["storage"]["start_soc"]) * self.s_E

        # interconnectors: grouped by far-end market and boundary side
        prices_cfg = load_yaml("ic_prices.yaml")["countries"]
        # every neighbouring market's price for the day (also reported, even if its links are off)
        self.foreign_prices = {cc: np.maximum(dem.piecewise_profile(pc[req.season]["knots"])
                                              - pc.get("wind_sensitivity", 0) * self.wind_lf
                                              - pc.get("solar_sensitivity", 0) * self.solar_lf, 1.0)
                               for cc, pc in prices_cfg.items()}
        self.foreign_names = {cc: pc.get("name", cc) for cc, pc in prices_cfg.items()}
        self.gI = i = Groups()
        i_cap, i_price = [], []
        for key, pos in _sig_groups(ic, bn, ["far_country"]):
            price = self.foreign_prices[key[0]]
            ccap = ic["capacity_mw"].to_numpy(float)[pos] * c["availability"]["interconnector"]
            i.members.append(pos); i.weights.append(ccap / ccap.sum()); i.tech.append(key[0])
            i_cap.append(ccap.sum()); i_price.append(np.maximum(price, 1.0))
        i.n = len(i.members); i.S = _S(ic, i.members, bn)
        self.i_cap = np.array(i_cap)
        self.i_price = np.array(i_price).reshape(i.n, T)

        # demand zones (regions on the same side of every boundary)
        self.gZ = z = Groups()
        z_net = []
        for _, pos in _sig_groups(rg, bn, []):
            z.members.append(pos); z_net.append(self.net_demand[pos].sum(0))
        z.n = len(z.members); z.S = _S(rg, z.members, bn)
        self.z_net = np.array(z_net)

        # ---------------------------------------------------------------- boundaries
        derate = 1.0
        if req.season == "summer":
            derate = req.summer_derate if req.summer_derate is not None else d.defaults["summer_derate"]
        self.derate = derate
        self.sign = np.array([1.0 if self.bcfg[b]["positive"] == "export" else -1.0 for b in bn])
        fwd = np.array([self.bcfg[b]["capability_mw"] for b in bn], float) * derate
        rev = np.array([(self.bcfg[b].get("reverse_capability_mw") or self.bcfg[b]["capability_mw"]) for b in bn],
                       float) * derate
        self.cap_fwd, self.cap_rev = fwd, rev
        self.enforced = np.array([self.bcfg[b]["core"] or req.enforce_optional for b in bn])
        self.D_inside = z.S @ self.z_net if z.n else np.zeros((nB, T))               # (nB, T) net demand inside

        # --------------------------------------------------------------- LP skeleton
        self.sizes = {"G": g.n, "R": r.n, "CH": s.n, "DIS": s.n, "SOC": s.n, "IC": i.n, "U": z.n, "SP": z.n}
        cyc = c["storage_cycling"] / 2.0
        self.cost = {                                          # GBP/MWh, (units, T)
            "G": np.repeat(self.g_cost[:, None], T, 1) if g.n else np.zeros((0, T)),
            "R": np.repeat(self.r_cost[:, None], T, 1) if r.n else np.zeros((0, T)),
            "CH": np.full((s.n, T), cyc), "DIS": np.full((s.n, T), cyc), "SOC": np.zeros((s.n, T)),
            "IC": self.i_price, "U": np.full((z.n, T), float(c["voll"])), "SP": np.full((z.n, T), float(c["spill_cost"])),
        }
        ic_cap = np.zeros_like(self.i_cap) if req.lock_ic else self.i_cap
        soc_lb = np.zeros((s.n, T)); soc_ub = np.repeat(self.s_E[:, None], T, 1) if s.n else np.zeros((0, T))
        if s.n:
            soc_lb[:, -1] = soc_ub[:, -1] = self.soc0                          # cyclic day
        rep = lambda v: np.repeat(np.asarray(v, float)[:, None], T, 1)
        self.lb = {"G": rep(self.g_min), "R": np.zeros((r.n, T)), "CH": np.zeros((s.n, T)), "DIS": np.zeros((s.n, T)),
                   "SOC": soc_lb, "IC": -rep(ic_cap), "U": np.zeros((z.n, T)), "SP": np.zeros((z.n, T))}
        self.ub = {"G": rep(self.g_cap), "R": self.r_avail.copy(), "CH": rep(self.s_P), "DIS": rep(self.s_P),
                   "SOC": soc_ub, "IC": rep(ic_cap), "U": np.full((z.n, T), np.inf), "SP": np.full((z.n, T), np.inf)}
        self.inj = {"G": (g.S, 1.0), "R": (r.S, 1.0), "DIS": (s.S, 1.0), "CH": (s.S, -1.0),
                    "IC": (i.S, 1.0), "U": (z.S, 1.0), "SP": (z.S, -1.0)}       # contribution to net injection

    # ------------------------------------------------------------------------------
    def _assemble(self, blocks: list[str], sizes: dict, nrows: int, parts: dict):
        return sparse.hstack([parts[b] if b in parts else sparse.csr_matrix((nrows, sizes[b] * T)) for b in blocks],
                             format="csr")

    def solve(self, constrained: bool, market: dict | None = None) -> dict:
        """Solve one pass. Storage cannot charge and discharge at once. An LP cannot say that
        directly, and when surplus wind makes energy worth less than nothing it will try to,
        because wasting energy in round-trip losses then pays. If that happens, every unit is
        locked to the direction it was (net) moving in each period and the pass is re-solved;
        locks accumulate, so this settles in a few rounds.

        The same incentive has a slower form: charge in one period, discharge in another while
        wind next door is still being curtailed, purely to lose energy in the round trip. So a
        unit may not discharge in a period where the local price (system price adjusted by the
        shadow prices of the boundaries it sits behind) is negative."""
        ub_ch, ub_dis = self.ub["CH"].copy(), self.ub["DIS"].copy()
        for attempt in range(MAX_STORAGE_FIXES + 1):
            res = self._solve_once(constrained, market, ub_ch, ub_dis)
            both = (res["CH"] > 0.5) & (res["DIS"] > 0.5)
            dumping = (res["DIS"] > 0.5) & (res["local_price"] < -1.0)
            if not (both.any() or dumping.any()) or attempt == MAX_STORAGE_FIXES:
                res["storage_fixes"] = attempt
                res["storage_overlap"] = bool(both.any())
                res["storage_dumping"] = bool(dumping.any())
                return res
            if dumping.any():
                ub_dis[res["local_price"] < -1.0] = 0.0
            net = res["DIS"] - res["CH"]
            ub_dis[net < -0.5] = 0.0                 # charging periods: no discharge
            ub_ch[net > 0.5] = 0.0                   # discharging periods: no charge
            idle = both & (np.abs(net) <= 0.5)
            ub_dis[idle] = 0.0; ub_ch[idle] = 0.0

    def _solve_once(self, constrained, market, ub_ch, ub_dis) -> dict:
        sizes = dict(self.sizes)
        blocks = list(BLOCKS)
        use_dev = constrained and market is not None
        if use_dev:
            for b in DEV_BLOCKS:
                for pre in ("DP_", "DM_"):
                    sizes[pre + b] = sizes[b]; blocks.append(pre + b)
        off, pos = {}, 0
        for b in blocks:
            off[b] = pos; pos += sizes[b] * T
        nvar = pos
        nS, nI = sizes["CH"], sizes["IC"]
        ones = lambda n: np.ones((1, n))
        eye = sparse.identity(T, format="csr")

        # ---- equalities: national balance, storage dynamics, (deviation definitions)
        A_eq = [self._assemble(blocks, sizes, T, {
            "G": _kron(ones(sizes["G"])), "R": _kron(ones(sizes["R"])), "DIS": _kron(ones(nS)),
            "CH": -_kron(ones(nS)), "IC": _kron(ones(nI)), "U": _kron(ones(sizes["U"])), "SP": -_kron(ones(sizes["SP"]))})]
        b_eq = [self.z_net.sum(0) if self.gZ.n else np.zeros(T)]
        if nS:
            diff = eye - sparse.eye(T, k=-1, format="csr")              # SOC[t] - SOC[t-1]
            A_eq.append(self._assemble(blocks, sizes, nS * T, {
                "SOC": sparse.kron(sparse.identity(nS), diff, format="csr"),
                "CH": _kron(np.diag(-self.s_eta * DT_H)), "DIS": _kron(np.diag(DT_H / self.s_eta))}))
            rhs = np.zeros((nS, T)); rhs[:, 0] = self.soc0
            b_eq.append(rhs.ravel())
        if use_dev:
            for b in DEV_BLOCKS:
                n = sizes[b] * T
                if n:
                    I = sparse.identity(n, format="csr")
                    A_eq.append(self._assemble(blocks, sizes, n, {b: I, "DP_" + b: -I, "DM_" + b: I}))
                    b_eq.append(market[b].ravel())

        # ---- inequalities: storage power, interconnector ramps, boundary limits
        A_ub, b_ub = [], []
        if nS:
            A_ub.append(self._assemble(blocks, sizes, nS * T, {"CH": _kron(np.eye(nS)), "DIS": _kron(np.eye(nS))}))
            b_ub.append(np.repeat(self.s_P, T))
        if nI:
            ramp = sparse.kron(sparse.identity(nI), (sparse.eye(T, k=0) - sparse.eye(T, k=-1)).tocsr()[1:], format="csr")
            lim = np.repeat(self.costs["interconnector"]["ramp_fraction_per_period"] * self.i_cap, T - 1)
            for sgn in (1.0, -1.0):
                A_ub.append(self._assemble(blocks, sizes, nI * (T - 1), {"IC": sgn * ramp}))
                b_ub.append(lim)
        n_before_boundaries = sum(m.shape[0] for m in A_ub)
        enf = np.flatnonzero(self.enforced) if constrained else np.array([], int)
        if len(enf):
            sg = self.sign[enf][:, None]
            flow = self._assemble(blocks, sizes, len(enf) * T,
                                  {b: _kron(S[enf] * sg * k) for b, (S, k) in self.inj.items()})
            A_ub += [flow, -flow]
            b_ub += [(self.cap_fwd[enf][:, None] + sg * self.D_inside[enf]).ravel(),
                     (self.cap_rev[enf][:, None] - sg * self.D_inside[enf]).ravel()]

        # ---- objective and bounds
        cvec, lb, ub = np.zeros(nvar), np.zeros(nvar), np.full(nvar, np.inf)
        for b in BLOCKS:
            sl = slice(off[b], off[b] + sizes[b] * T)
            cvec[sl] = (self.cost[b] * DT_H).ravel()
            lb[sl] = self.lb[b].ravel()
            ub[sl] = (ub_ch if b == "CH" else ub_dis if b == "DIS" else self.ub[b]).ravel()
        if use_dev:
            cvec[off["DP_G"]:] = self.costs["redispatch_epsilon"] * DT_H

        res = linprog(cvec, A_ub=sparse.vstack(A_ub, format="csr") if A_ub else None,
                      b_ub=np.concatenate(b_ub) if b_ub else None,
                      A_eq=sparse.vstack(A_eq, format="csr"), b_eq=np.concatenate(b_eq),
                      bounds=np.column_stack([lb, ub]), method="highs")
        if res.status != 0:
            raise RuntimeError(f"LP failed ({'constrained' if constrained else 'market'} pass): {res.message}")

        out = {b: res.x[off[b]: off[b] + sizes[b] * T].reshape(sizes[b], T) for b in BLOCKS}
        out["price"] = np.asarray(res.eqlin.marginals[:T]) / DT_H            # system marginal price, GBP/MWh
        shadow = np.zeros((len(self.bnames), T))
        if len(enf):
            m = np.asarray(res.ineqlin.marginals[n_before_boundaries:]).reshape(2, len(enf), T)
            shadow[enf] = (np.abs(m[0]) + np.abs(m[1])) / DT_H
        out["shadow"] = shadow
        # Local value of energy for each storage unit, GBP/MWh. A binding export limit makes
        # energy cheaper inside it; a binding import limit makes it dearer.
        local = np.repeat(out["price"][None, :], nS, 0)
        if len(enf) and nS:
            signed = (m[0] - m[1]) / DT_H * self.sign[enf][:, None]                 # (enforced, T)
            local = local + self.gS.S[enf].T @ signed
        out["local_price"] = local
        return out

    # ------------------------------------------------------------------------------
    def net_injection(self, sol: dict) -> np.ndarray:
        """(n_boundaries, T) net injection on the inside side of each boundary."""
        inj = -self.D_inside.copy()
        for b, (S, k) in self.inj.items():
            if S.shape[1]:
                inj += k * (S @ sol[b])
        return inj

    def period_cost(self, sol: dict) -> np.ndarray:
        """GBP per period. Curtailment is charged at the curtailment cost (not rewarded as
        negative generation cost), so the number is a real cost."""
        cost = np.zeros(T)
        for b in BLOCKS:
            if b != "R":
                cost += (self.cost[b] * sol[b]).sum(0) * DT_H
        cost += (-self.r_cost[:, None] * (self.r_avail - sol["R"])).sum(0) * DT_H
        return cost

    def per_asset(self, sol: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Share group results out pro rata -> (asset MW, storage SoC MWh, interconnector MW)."""
        P = np.zeros((len(self.assets), T)); soc = np.zeros((len(self.assets), T)); ic = np.zeros((len(self.ics), T))
        for k, (m, w) in enumerate(zip(self.gG.members, self.gG.weights)):
            P[m] = w[:, None] * sol["G"][k]
        for k, (m, w) in enumerate(zip(self.gR.members, self.gR.weights)):
            P[m] = w * sol["R"][k]
        for k, (m, w) in enumerate(zip(self.gS.members, self.gS.weights)):
            P[m] = w[:, None] * (sol["DIS"][k] - sol["CH"][k])
            soc[m] = w[:, None] * sol["SOC"][k]
        for k, (m, w) in enumerate(zip(self.gI.members, self.gI.weights)):
            ic[m] = w[:, None] * sol["IC"][k]
        return P, soc, ic


# ====================================================================================
def simulate(req: SimRequest) -> dict:
    t0 = time.perf_counter()
    pb = Problem(req)
    market = pb.solve(constrained=False)
    cons = pb.solve(constrained=True, market=market)
    solve_s = time.perf_counter() - t0

    c = pb.costs
    a, ics, rg, bn = pb.assets, pb.ics, pb.regions, pb.bnames
    P1, _, IC1 = pb.per_asset(market)
    P2, SOC2, IC2 = pb.per_asset(cons)
    action = P2 - P1

    # ------------------------------------------------------------------ boundaries
    sign = pb.sign[:, None]
    inj1, inj2 = pb.net_injection(market), pb.net_injection(cons)
    flow1, flow2 = sign * inj1, sign * inj2
    cap = np.where(flow2 >= 0, pb.cap_fwd[:, None], pb.cap_rev[:, None])
    at_limit = np.abs(flow2) >= 0.999 * cap
    beyond = np.where(flow2 >= 0, flow1 > cap + 1.0, flow1 < -cap - 1.0)
    binding = at_limit & beyond & pb.enforced[:, None]

    tech = a["tech"].to_numpy()
    is_store = np.isin(tech, STORAGE)
    A_in = a[bn].to_numpy(float).T                       # (nB, assets)
    I_in = ics[bn].to_numpy(float).T if len(ics) else np.zeros((len(bn), 0))
    R_in = rg[bn].to_numpy(float).T
    gen_in = A_in[:, ~is_store] @ P2[~is_store] + R_in @ (pb.emb_wind + pb.emb_solar)
    dem_in = R_in @ pb.underlying
    chg_in = -(A_in[:, is_store] @ P2[is_store])
    imp_in = I_in @ IC2

    # which binding boundaries does each constraint action help?
    relieves: dict[tuple[int, int], list[str]] = {}
    for bi, t in zip(*np.nonzero(binding)):
        helping = sign[bi, 0] * np.sign(flow2[bi, t]) * action[:, t] < -1.0       # reduces |flow| from inside
        for ai in np.flatnonzero(helping & (A_in[bi] > 0)):
            relieves.setdefault((ai, t), []).append(bn[bi])

    # ---------------------------------------------------------------------- totals
    cost1, cost2 = pb.period_cost(market), pb.period_cost(cons)
    by_tech = {t_: P2[tech == t_].sum(0) for t_ in THERMAL + RENEWABLE}
    dis = {t_: np.clip(P2[tech == t_], 0, None).sum(0) for t_ in STORAGE}
    chg = {t_: np.clip(-P2[tech == t_], 0, None).sum(0) for t_ in STORAGE}
    imports, exports = np.clip(IC2, 0, None).sum(0), np.clip(-IC2, 0, None).sum(0)
    emb_w, emb_s, underlying = pb.emb_wind.sum(0), pb.emb_solar.sum(0), pb.underlying.sum(0)
    unserved, spill = cons["U"].sum(0), cons["SP"].sum(0)
    is_wind = np.isin(tech, ["wind_offshore", "wind_onshore"])
    is_solar = tech == "solar"
    curt = pb.avail - P2
    curt_w, curt_s = curt[is_wind].sum(0), curt[is_solar].sum(0)
    curt_w_mkt = (pb.avail - P1)[is_wind].sum(0)
    energy_soc = SOC2[is_store].sum(0)

    ci = c["carbon"]
    emissions = sum(by_tech[t_] * ci[t_] for t_ in THERMAL)                       # kg/h (MW x g/kWh)
    far = ics["far_country"].to_numpy() if len(ics) else np.array([])
    for k in range(len(ics)):
        emissions = emissions + np.clip(IC2[k], 0, None) * ci["imports"].get(far[k], 300)
    supplied = sum(by_tech.values()) + emb_w + emb_s + imports
    carbon = np.divide(emissions, supplied, out=np.zeros(T), where=supplied > 1)

    # --------------------------------------------------------------------- periods
    r1 = lambda v: round(float(v), 1)
    ids, ic_ids, rg_ids = a["id"].tolist(), ics["id"].tolist(), rg["id"].tolist()
    is_ren = np.isin(tech, RENEWABLE)
    periods = []
    for t in range(T):
        h0, h1 = t * 30, (t + 1) * 30
        label = f"SP {t + 1} · {h0 // 60:02d}:{h0 % 60:02d}–{(h1 // 60) % 24:02d}:{h1 % 60:02d}"
        assets = {}
        for k, aid in enumerate(ids):
            e = {"p": r1(P2[k, t]), "action": r1(action[k, t])}
            if is_store[k]:
                e["soc"] = r1(SOC2[k, t])
            if is_ren[k]:
                e["avail"] = r1(pb.avail[k, t])
            if (k, t) in relieves:
                e["relieves"] = relieves[(k, t)]
            assets[aid] = e
        boundaries = {b: {
            "flow": r1(flow2[i, t]), "flow_unconstrained": r1(flow1[i, t]), "cap": r1(cap[i, t]),
            "binding": bool(binding[i, t]), "at_limit": bool(at_limit[i, t]), "enforced": bool(pb.enforced[i]),
            "shadow_price": r1(cons["shadow"][i, t]),
            "gen": r1(gen_in[i, t]), "demand": r1(dem_in[i, t]),
            "storage_charging": r1(chg_in[i, t]), "imports": r1(imp_in[i, t]),
        } for i, b in enumerate(bn)}
        mix = {t_: r1(v[t]) for t_, v in by_tech.items()}
        mix.update(embedded_wind=r1(emb_w[t]), embedded_solar=r1(emb_s[t]),
                   pumped_storage=r1(dis["pumped_storage"][t]), battery=r1(dis["battery"][t]), imports=r1(imports[t]))
        periods.append({
            "sp": t + 1, "label": label,
            "assets": assets,
            "ic": {i_: r1(IC2[k, t]) for k, i_ in enumerate(ic_ids)},
            "ic_market": {i_: r1(IC1[k, t]) for k, i_ in enumerate(ic_ids)},
            "boundaries": boundaries,
            "regions": {r_: {"demand": r1(pb.underlying[k, t]), "emb_solar": r1(pb.emb_solar[k, t]),
                             "emb_wind": r1(pb.emb_wind[k, t])} for k, r_ in enumerate(rg_ids)},
            "totals": {
                "demand": r1(underlying[t]), "mix": mix,
                "charging": {"pumped_storage": r1(chg["pumped_storage"][t]), "battery": r1(chg["battery"][t])},
                "exports": r1(exports[t]), "unserved": r1(unserved[t]), "spill": r1(spill[t]),
                "curtailed_wind": r1(curt_w[t]), "curtailed_solar": r1(curt_s[t]),
                "curtailed_wind_market": r1(curt_w_mkt[t]),
                "cost": r1(cost2[t]), "cost_market": r1(cost1[t]), "constraint_cost": r1(cost2[t] - cost1[t]),
                "market_price": r1(market["price"][t]), "carbon_intensity": r1(carbon[t]),
                "soc_total": r1(energy_soc[t]),
                "wind_lf": round(float(pb.wind_lf[t]), 3), "solar_lf": round(float(pb.solar_lf[t]), 3),
            },
        })

    # --------------------------------------------------------------------- summary
    gwh = lambda v: round(float(v.sum()) * DT_H / 1000.0, 2)
    curtailed_gwh = gwh(curt_w) + gwh(curt_s)
    summary = {
        "curtailed_wind_gwh": gwh(curt_w), "curtailed_solar_gwh": gwh(curt_s),
        "curtailed_gwh": round(curtailed_gwh, 2),
        "curtailed_gwh_market": round(gwh(curt_w_mkt) + gwh((pb.avail - P1)[is_solar].sum(0)), 2),
        "homes_for_a_day": int(round(curtailed_gwh * 1e6 / c["homes_kwh_per_day"], -3)),
        "constraint_cost": round(float((cost2 - cost1).sum())),
        "cost": round(float(cost2.sum())), "cost_market": round(float(cost1.sum())),
        "carbon_intensity": r1(np.divide((emissions * DT_H).sum(), (supplied * DT_H).sum())) if supplied.sum() > 0 else 0.0,
        "unserved_gwh": gwh(unserved), "spill_gwh": gwh(spill),
        "peak_demand_mw": r1(underlying.max()),
        "binding_periods": {b: int(binding[i].sum()) for i, b in enumerate(bn)},
        "max_overshoot_mw": {b: r1(np.max(np.abs(flow1[i]) - cap[i])) for i, b in enumerate(bn)},
        "solve_seconds": round(solve_s, 3),
        "lp": {"groups": {k: v for k, v in pb.sizes.items() if k not in ("DIS", "SOC", "SP")},
               "storage_fixes": [market["storage_fixes"], cons["storage_fixes"]],
               "storage_overlap": market["storage_overlap"] or cons["storage_overlap"],
               "storage_dumping": market["storage_dumping"] or cons["storage_dumping"]},
    }
    weather = {
        **wx.preview(req.wind, req.cloud, req.season), **wx.sun(req.season),
        "season": req.season, "summer_derate": pb.derate,
        "wind_lf_mean": round(float(pb.wind_lf.mean()), 3), "solar_lf_peak": round(float(pb.solar_lf.max()), 3),
    }
    prices = {"GB": [r1(v) for v in market["price"]],
              **{cc: [r1(v) for v in pb.foreign_prices[cc]] for cc in pb.foreign_prices},
              "names": {"GB": "Great Britain", **pb.foreign_names},
              "note": "GB = system marginal price of the market (unconstrained) pass; others are the illustrative profiles in config/ic_prices.yaml"}
    return {"request": req.model_dump(), "weather": weather, "periods": periods, "summary": summary, "prices": prices}
