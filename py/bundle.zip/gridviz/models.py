"""Request / response schemas for the API."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field

TECHS = ["wind_offshore", "wind_onshore", "solar", "ccgt", "ocgt", "biomass", "nuclear",
         "pumped_storage", "battery"]
LAYER_TYPES = TECHS + ["interconnector"]


class SimRequest(BaseModel):
    wind: float = Field(0.5, ge=0, le=1, description="Weather pad Y: 0 = calm, 1 = gale")
    cloud: float = Field(0.5, ge=0, le=1, description="Cloud cover: 0 = clear sky, 1 = overcast")
    season: Literal["winter", "summer"] = "winter"
    seed: int = 0
    front: bool = Field(False, description="Weather front: wind arrives in the north first and sweeps south")
    excluded_types: list[str] = Field(default_factory=list, description=f"Any of {LAYER_TYPES}")
    excluded_assets: list[str] = Field(default_factory=list, description="Asset or interconnector ids")
    lock_ic: bool = Field(False, description="Hold every interconnector at 0 MW")
    summer_derate: Optional[float] = Field(None, gt=0, le=1.5, description="Overrides config/boundaries.yaml")
    start_soc: Optional[float] = Field(None, ge=0, le=1, description="Storage state of charge at 00:00 (and 24:00)")
    enforce_optional: bool = Field(False, description="Also enforce the optional boundaries (B2, B5, SC1, B13)")

    def cache_key(self) -> str:
        d = self.model_dump()
        d["excluded_types"] = sorted(d["excluded_types"])
        d["excluded_assets"] = sorted(d["excluded_assets"])
        return repr(sorted(d.items()))


# ---- response (documented here; the server returns plain dicts for speed) ----------
class AssetPeriod(BaseModel):
    p: float                          # MW after constraint actions. Storage: + discharging, - charging
    action: float = 0.0               # MW, constrained minus market (+ turned up, - turned down)
    soc: Optional[float] = None       # MWh (storage only)
    avail: Optional[float] = None     # MW the weather would allow (wind / solar only)
    relieves: Optional[list[str]] = None   # binding boundaries this action helps


class BoundaryPeriod(BaseModel):
    flow: float                       # MW, constrained pass, in the boundary's positive direction
    flow_unconstrained: float         # MW, market pass
    cap: float                        # MW, in the direction of the unconstrained flow
    binding: bool
    enforced: bool
    shadow_price: float               # GBP/MWh the LP would pay for 1 MW more capability
    gen: float                        # MW generated on the inside side (incl. embedded)
    demand: float                     # MW underlying demand on the inside side
    storage_charging: float           # MW net charging on the inside side
    imports: float                    # MW net interconnector import on the inside side


class Period(BaseModel):
    sp: int
    label: str
    assets: dict[str, AssetPeriod]
    ic: dict[str, float]
    ic_market: dict[str, float]
    boundaries: dict[str, BoundaryPeriod]
    regions: dict[str, dict[str, float]]
    totals: dict


class SimResponse(BaseModel):
    request: dict
    weather: dict
    periods: list[Period]
    summary: dict
