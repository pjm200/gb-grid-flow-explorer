"""Demand profiles and their regional split (spec section 6.4)."""
from __future__ import annotations

from functools import lru_cache

import numpy as np
from scipy.interpolate import PchipInterpolator

from . import load_yaml
from .weather import HOURS


@lru_cache(maxsize=1)
def cfg() -> dict:
    return load_yaml("demand.yaml")


def knots_to_profile(knots) -> np.ndarray:
    """Smooth periodic curve through [hour, value] knots, sampled at the 48 period midpoints."""
    k = np.array(sorted(knots), float)
    k = k[k[:, 0] < 24.0]
    h = np.concatenate([k[-2:, 0] - 24.0, k[:, 0], k[:2, 0] + 24.0])
    v = np.concatenate([k[-2:, 1], k[:, 1], k[:2, 1]])
    return PchipInterpolator(h, v)(HOURS)


def piecewise_profile(knots) -> np.ndarray:
    """Linear interpolation through [hour, value] knots (used for external prices)."""
    k = np.array(sorted(knots), float)
    return np.interp(HOURS, k[:, 0], k[:, 1], period=24.0 if k[-1, 0] < 24 else None)


@lru_cache(maxsize=1)
def processed() -> dict | None:
    """Profiles built from NESO Historic Demand Data by prepare_data, if available."""
    import json

    from . import PROCESSED

    path = PROCESSED / "demand_profiles.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def source() -> str:
    p = processed()
    return f"{p['source']} {', '.join(map(str, p['years']))}" if p else "hand-drawn typical day (config/demand.yaml)"


def national_underlying_mw(season: str) -> np.ndarray:
    """Underlying GB demand (ND + embedded wind + embedded solar), MW per period.
    Settlement period k covers hours (k-1)/2 to k/2, matching the model's period k-1."""
    p = processed()
    if p:
        return np.asarray(p[season], float)
    return knots_to_profile(cfg()["profiles"][season]["knots"]) * 1000.0


def embedded_capacity() -> dict:
    """Embedded (distribution-connected) wind and solar capacity, MW."""
    p = processed()
    if p:
        return {"wind_capacity_mw": p["embedded"]["wind_capacity_mw"], "solar_capacity_mw": p["embedded"]["solar_capacity_mw"]}
    return cfg()["embedded"]


def regional_underlying_mw(season: str, shares: np.ndarray) -> np.ndarray:
    """(n_regions, 48) underlying demand, split by fixed regional shares."""
    return np.asarray(shares, float)[:, None] * national_underlying_mw(season)[None, :]
