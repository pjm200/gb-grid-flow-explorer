"""Synthetic weather -> wind and solar capacity factors (spec section 6.3).

All functions return arrays shaped (n_points, 48): one row per site, one column per
half-hour settlement period (local time, period midpoints).
"""
from __future__ import annotations

from functools import lru_cache

import numpy as np
import pandas as pd

from . import N_PERIODS, load_yaml

HOURS = (np.arange(N_PERIODS) + 0.5) * 0.5          # 0.25, 0.75, ... 23.75
CENTRE = (53.0, -1.5)                               # reference point for sunrise / sun elevation


@lru_cache(maxsize=1)
def cfg() -> dict:
    return load_yaml("weather.yaml")


def period_times(season: str) -> pd.DatetimeIndex:
    date = cfg()["season"][season]["date"]
    start = pd.Timestamp(date, tz="Europe/London")
    return start + pd.to_timedelta(HOURS, unit="h")


# ---------------------------------------------------------------------- noise
class NoiseField:
    """Smooth, reproducible, spatially correlated noise: a sum of travelling plane waves.
    Nearby sites get similar values; the same seed always gives the same field."""

    def __init__(self, seed: int, salt: int):
        c = cfg()["noise"]
        rng = np.random.default_rng([int(seed) & 0x7FFFFFFF, salt])
        k = c["n_waves"]
        self.wavelength = rng.uniform(*c["wavelength_km"], k)
        self.period = rng.uniform(*c["period_h"], k)
        self.theta = rng.uniform(0, 2 * np.pi, k)
        self.phase = rng.uniform(0, 2 * np.pi, k)
        self.scale = np.sqrt(2.0 / k)                # unit variance

    def __call__(self, lat, lon) -> np.ndarray:
        x = np.asarray(lon, float)[:, None, None] * 65.0      # km east (approx at 54N)
        y = np.asarray(lat, float)[:, None, None] * 111.0     # km north
        t = HOURS[None, :, None]
        arg = (2 * np.pi * (x * np.cos(self.theta) + y * np.sin(self.theta)) / self.wavelength
               + 2 * np.pi * t / self.period + self.phase)
        return self.scale * np.cos(arg).sum(axis=2)


# ----------------------------------------------------------------------- wind
def mean_wind_speed(y: float) -> float:
    w = cfg()["wind"]
    return w["mean_speed_min"] + w["mean_speed_span"] * float(np.clip(y, 0, 1))


def power_curve(v) -> np.ndarray:
    """Generic turbine: zero below cut-in, cubic to rated, flat, zero above storm cut-out."""
    pc = cfg()["wind"]["power_curve"]
    v = np.asarray(v, float)
    cubic = (v ** 3 - pc["cut_in"] ** 3) / (pc["rated"] ** 3 - pc["cut_in"] ** 3)
    out = np.clip(cubic, 0.0, 1.0)
    out[(v < pc["cut_in"]) | (v > pc["cut_out"])] = 0.0
    return out


def wind_speed(y: float, lat, lon, kind, seed: int = 0, front: bool = False) -> np.ndarray:
    """Hub-height wind speed (m/s). `kind` per site: 'offshore', 'scotland_onshore' or
    'england_wales_onshore'."""
    w = cfg()["wind"]
    lat = np.asarray(lat, float)
    factor = np.array([w["regional_factor"][k] for k in kind])[:, None]
    onshore = np.array([k != "offshore" for k in kind])[:, None]
    diurnal = 1.0 + onshore * w["diurnal_amplitude"] * np.sin(2 * np.pi * (HOURS[None, :] - 9.0) / 24.0)
    sigma = w["noise_sigma"]
    noise = np.exp(sigma * NoiseField(seed, 1)(lat, lon) - sigma ** 2 / 2)
    v = mean_wind_speed(y) * factor * diurnal * noise
    if front:
        f = w["front"]
        lat_front = f["lat_start"] + (f["lat_end"] - f["lat_start"]) * HOURS[None, :] / 24.0
        behind = 1.0 / (1.0 + np.exp(-(lat[:, None] - lat_front) / f["width_deg"]))
        v = v * (f["ahead_factor"] + (f["behind_factor"] - f["ahead_factor"]) * behind)
    return v


def wind_cf(y: float, lat, lon, kind, seed: int = 0, front: bool = False) -> np.ndarray:
    return power_curve(wind_speed(y, lat, lon, kind, seed, front)) * cfg()["wind"]["availability"]


# ---------------------------------------------------------------------- solar
# Sun geometry is precomputed by prepare_data into data/processed/solar_tables.json, so the
# model needs no pvlib at run time (the browser version cannot load it). pvlib is only the
# fallback when the table is missing or a point falls outside it.
TABLE_LAT = (49.5, 61.0)
TABLE_LON = (-8.5, 2.5)


@lru_cache(maxsize=1)
def _tables() -> dict | None:
    import json

    from . import PROCESSED

    path = PROCESSED / "solar_tables.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def _pvlib_clear_sky(season: str, lat_r: float, lon_r: float) -> tuple:
    from pvlib.location import Location

    cs = Location(lat_r, lon_r, tz="Europe/London").get_clearsky(
        period_times(season), model="ineichen", linke_turbidity=3.0)
    return tuple(cs["ghi"].to_numpy())


@lru_cache(maxsize=1024)
def _clear_sky_ghi(season: str, lat_r: float, lon_r: float) -> tuple:
    t = _tables()
    if t:
        hit = t["seasons"][season]["ghi"].get(f"{lat_r:.1f},{lon_r:.1f}")
        if hit is not None:
            return tuple(hit)
    return _pvlib_clear_sky(season, lat_r, lon_r)


def _pvlib_sun(season: str) -> dict:
    import pvlib

    times = period_times(season)
    pos = pvlib.solarposition.get_solarposition(times, *CENTRE)
    day = pd.DatetimeIndex([times[0].normalize() + pd.Timedelta(hours=12)])
    rs = pvlib.solarposition.sun_rise_set_transit_spa(day, *CENTRE)
    fmt = lambda ts: ts.tz_convert("Europe/London").strftime("%H:%M")
    return {"elevation": [round(float(e), 2) for e in pos["apparent_elevation"]],
            "sunrise": fmt(rs["sunrise"].iloc[0]), "sunset": fmt(rs["sunset"].iloc[0]),
            "date": times[0].strftime("%Y-%m-%d")}


def build_solar_tables() -> dict:
    """Clear-sky GHI on the 0.5 degree grid over GB, plus sun position at the reference point,
    for both seasons (uses pvlib; run by prepare_data)."""
    lats = np.arange(TABLE_LAT[0], TABLE_LAT[1] + 1e-9, 0.5)
    lons = np.arange(TABLE_LON[0], TABLE_LON[1] + 1e-9, 0.5)
    out = {"grid_step": 0.5, "lat": list(TABLE_LAT), "lon": list(TABLE_LON), "seasons": {}}
    for season in cfg()["season"]:
        ghi = {f"{a:.1f},{o:.1f}": [round(float(v), 1) for v in _pvlib_clear_sky(season, float(a), float(o))]
               for a in lats for o in lons}
        out["seasons"][season] = {"ghi": ghi, **_pvlib_sun(season)}
    return out


def clear_sky_ghi(season: str, lat, lon) -> np.ndarray:
    """Clear-sky global horizontal irradiance, W/m2 (pvlib Ineichen), on a 0.5 degree grid."""
    return np.array([_clear_sky_ghi(season, round(float(a) * 2) / 2, round(float(o) * 2) / 2)
                     for a, o in zip(lat, lon)])


def clear_sky_index(cloud) -> np.ndarray:
    s = cfg()["solar"]
    return 1.0 - s["kasten_a"] * np.clip(cloud, 0, 1) ** s["kasten_b"]


def cloud_field(cloud: float, lat, lon, seed: int = 0) -> np.ndarray:
    """Local cloud fraction: the pad value plus moving spatial variation that vanishes
    at fully clear and fully overcast."""
    c = float(np.clip(cloud, 0, 1))
    amp = cfg()["solar"]["cloud_noise"] * 2.0 * np.sqrt(c * (1 - c))
    return np.clip(c + amp * NoiseField(seed, 2)(lat, lon), 0.0, 1.0)


def solar_cf(cloud: float, season: str, lat, lon, seed: int = 0) -> np.ndarray:
    s = cfg()["solar"]
    k = clear_sky_index(cloud_field(cloud, lat, lon, seed))
    return np.minimum(1.0, k * clear_sky_ghi(season, lat, lon) / 1000.0 * s["performance_ratio"])


# ------------------------------------------------------------------- sun / meta
@lru_cache(maxsize=4)
def sun(season: str) -> dict:
    t = _tables()
    if t and season in t["seasons"]:
        s = t["seasons"][season]
        return {"elevation": s["elevation"], "sunrise": s["sunrise"], "sunset": s["sunset"], "date": s["date"]}
    return _pvlib_sun(season)


def preview(wind: float, cloud: float, season: str) -> dict:
    """The read-outs beside the weather pad."""
    w = cfg()["wind"]
    v = mean_wind_speed(wind)
    lf = float(power_curve(np.array([v * w["regional_factor"]["offshore"],
                                     v * w["regional_factor"]["scotland_onshore"],
                                     v * w["regional_factor"]["england_wales_onshore"]])).mean()) * w["availability"]
    return {"mean_wind_speed_ms": round(v, 1), "fleet_wind_load_factor": round(lf, 3),
            "clear_sky_index": round(float(clear_sky_index(cloud)), 3),
            "sunrise": sun(season)["sunrise"], "sunset": sun(season)["sunset"]}
